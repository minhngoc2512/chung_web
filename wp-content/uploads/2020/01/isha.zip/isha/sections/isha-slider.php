<?php if(get_theme_mod('slider_enable','1') == 1):?>
<!-- Hero Area -->
<section class="hero-area">
    <div class="home-slider">
        <?php isha_frontpage_slider_items();?>
    </div>
</section>
<!--/ End Hero Area -->
<?php endif;?>